package Aplicacion;

public class Manzana extends Sorpresa {
	public Manzana(Posicion posi, String root) {
		super(posi,"manzana");
	}
	
	public void efecto(Player p) {
		if(isVisible()) {
			p.sumeScore(5);
			setVisible(false);
		}
	}
}
