package Aplicacion;

public class BrokenStair extends Stair {

	public BrokenStair(Posicion abajoInicial, Posicion abajoFinal, Posicion arribaInicial, Posicion arribaFinal) {
		super(abajoInicial, abajoFinal, arribaInicial, arribaFinal);
		setBroken(true);
	}

}
